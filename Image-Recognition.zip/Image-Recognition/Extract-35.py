
import base64
import csv
import hashlib,sys
import hmac
import urllib, os
from urllib.parse import urlparse

from geopy import location
from geopy.geocoders import Nominatim
from openpyxl import Workbook
from openpyxl import load_workbook  
import openpyxl
from openpyxl.chart.data_source import StrVal
from openpyxl.worksheet import worksheet
	
import DuplicateCheck as dc


complete = False
pickFlag = False
nameRow = 1


def pickNames():

	
	samListpath = configdict['samListPath'] 
	Name_From_List = []

	nameRow = 1

	NameBook = openpyxl.load_workbook(samListpath)

	WorkSheet = NameBook.active

	while(WorkSheet['A' + str(nameRow)].value != None):

		Name_From_List.append(str(WorkSheet['A' + str(nameRow)].value))

		nameRow += 1

	return Name_From_List


'''def getStreet(Add, SaveLoc):
 
	print ("downloading Image: " + Add)
	base = "https://maps.googleapis.com/maps/api/streetview?size=2048x2048&location="
	# key = input("Please enter your google key")
	# key = "&key="+key
	key = "&key=AIzaSyAp6od3hev1dvEP4uYhZ4xNX2O7PlRHFYI" 
	MyUrl = base + Add + key
	fi = Add + ".jpg"
	urllib.request.urlretrieve(MyUrl, os.path.join(SaveLoc, fi))
	return fi   ''' 


def sign_url(input_url=None, secret=None):  


	if not input_url or not secret:

		raise Exception("Both input_url and secret are required")

 

	url = urlparse(input_url)

	# We only need to sign the path+query part of the string

	url_to_sign = url.path + "?" + url.query
	#url_to_sign.encode('utf-8')
	# Decode the private key into its binary format

	# We need to decode the URL-encoded private key

	decoded_key = base64.urlsafe_b64decode(secret)
	#decoded_key.encode('utf-8')
	# Create a signature using the private key and the URL-encoded

	# string using HMAC SHA1. This signature will be binary.

	signature = hmac.new(decoded_key, url_to_sign, hashlib.sha1)

	# Encode the binary signature into base64 for use within a URL

	encoded_signature = base64.urlsafe_b64encode(signature.digest())

	original_url = url.scheme + "://" + url.netloc + url.path + "?" + url.query

	# Return signed URL

	return original_url + "&signature=" + encoded_signature

	

def getStreet(Add, SaveLoc):

	# base = "https://maps.googleapis.com/maps/api/streetview?size=1024x1024&scale=4&location="

	print ("downloading image: " + Add)

	fileName = SaveLoc + "\\" + Add + ".jpg"

	if not os.path.exists(fileName):
				
		base = "https://maps.googleapis.com/maps/api/streetview?size=2048x2048&location="
		# key = input("Please enter your google key")
		# key = "&key="+key
		key = "&key=AIzaSyAp6od3hev1dvEP4uYhZ4xNX2O7PlRHFYI" 
		MyUrl = base + Add + key
		fi = Add + ".jpg"
		urllib.request.urlretrieve(MyUrl, os.path.join(SaveLoc, fi))
		return fi

	else :
		return str(Add + ".jpg")

	
def getOuputFileName(Name_From_List):
	
	# OUTPUT FILE LOCATION
	SaveLocation =  configdict['TLSOutputPath']  + Name_From_List + "\\"
	
	# TO CREATE OUTPUT FOLDER
	if not os.path.exists(SaveLocation):
		os.makedirs(SaveLocation)
	
	# OUTPUT FILENAME
	SaveFile = Name_From_List + ".xlsx";
	Savefilepath = SaveLocation + SaveFile
	return Savefilepath
	
def processFile(Name_From_List, counter, processName, nssCom, tDict, pDict):

	print("processFile...")
	
	Savefilepath = getOuputFileName(Name_From_List)
	
	if counter == 1:
		# TO CREATE OUTPUT FILE IN PATH
		wb = openpyxl.Workbook()
		wb.save(Savefilepath)
		
	wb = load_workbook(Savefilepath, data_only=True)
	ws = wb.get_sheet_by_name("Sheet")
	
	for fKey, fValue in pDict.items():
	
		# WRITE VALUE TO OUTPUT FILE
		wNBN_Id = "A" + str(counter)
		wJoint_Use = "C" + str(counter)
		wPole_ownership = "D" + str(counter)  
		wLatitude = "E" + str(counter)
		wLongitude = "F" + str(counter) 
		wSource = "G" + str(counter)
		wIname = "H" + str(counter)
		wtag_id = "J" + str(counter)
		wutility_id = "K" + str(counter)
		wtls_id = "L" + str(counter)
	  
		# WRITE INTO OUTPUT
		if counter == 1:
			ws["A1"] = "NBN_ID"
			ws["B1"] = "Utility_ID"
			ws["C1"] = "Joint_Use"
			ws["D1"] = "Pole_ownership"
			ws["E1"] = "Latitude"
			ws["F1"] = "Longitude"
			ws["G1"] = "Source"
			ws["H1"] = "ImageName"
			ws["I1"] = "Duplicate"
			ws["J1"] = "tag_id"
			ws["K1"] = "utility_id"
			ws["L1"] = "tls_id"
			ws["M1"] = "pdb_id"      
		else:
			ws[wNBN_Id] = fValue.split("|")[1]
			ws[wPole_ownership] = fValue.split("|")[2]
			ws[wJoint_Use] = fValue.split("|")[3]
			ws[wLatitude] = fKey.split(",")[0]
			ws[wLongitude] = fKey.split(",")[1]
		   
			
			if(fValue.split("|")[4] != ""):
				ws[wtag_id] = fValue.split("|")[4]
			
			
			if (processName == "TPNI") :   

				ws[wtls_id] = fValue.split("|")[0]
				ws[wIname] = fValue.split("|")[5]
				ws[wSource] = fValue.split("|")[6]
				checkDuplicate = 0
				
			elif (processName == "utility") : 
				
				wUtility_Id = "B" + str(counter)
				ws[wUtility_Id] = fValue.split("|")[0]
				ws[wutility_id] = fValue.split("|")[5]
				ws[wIname] = fValue.split("|")[6]
				ws[wSource] = fValue.split("|")[7]
				checkDuplicate = 1

				
			if (checkDuplicate == 0):
				checkRadius(fKey.split(",")[0], fKey.split(",")[1], ws, counter, tDict, nssCom, "TPNI")
			elif (checkDuplicate == 1):
				checkRadius(fKey.split(",")[0], fKey.split(",")[1], ws, counter, tDict, nssCom, "UTILITY")
				
		counter += 1
		
	wb.save(Savefilepath)
	
	
	return counter
	
def readXls(folderName, fileName,samName):
	
	if fileName.__eq__(configdict['TPNIFileName']) :            
				print("Started Telstra Poles downloading")
				Pole_ownership = "H"
				Joint_Use = "J"
		# sLat = input("Which Column has the Latitude?")
				Lat = "K"
		# sLong = input("Which Column has the Longitude?")
				Longt = "L"
				Source = "Telstra"
				tls_id = "B"
				tag_id = "F"
				SaveImageLocation = configdict['TPNIImageLocation'] + samName + "\\"

	elif fileName.__eq__(configdict['UtilFileName']) :
				print("Started Utility Poles downloading")
				Utility_Id = "D"
				Pole_ownership = "H"
				Joint_Use = "J"
		# sLat = input("Which Column has the Latitude?")
				Lat = "K"
		# sLong = input("Which Column has the Longitude?")
				Longt = "L"
				tag_id = "F"
				utility_id = "A"
				Source = "Utility"
				SaveImageLocation = configdict['utilImageLocation'] + samName + "\\"
	   
	NBN_Id = "G"
	
	if not os.path.exists(SaveImageLocation):
		os.makedirs(SaveImageLocation)
	
	
	workbook1 = load_workbook(folderName + "\\\\" + fileName, data_only=True)
	TPNISheet = workbook1.get_sheet_names()[0]
	worksheet = workbook1.get_sheet_by_name(TPNISheet)
	
	xlsDict = {}
	count = 2
	for row in worksheet.iter_rows():
		
		# GET VALUE FROM INPUT FILE
		sNBN_Id = NBN_Id + str(count)
		sPole_ownership = Pole_ownership + str(count)
		sJoint_Use = Joint_Use + str(count)
		sLatitude = Lat + str(count)
		sLongitude = Longt + str(count)
		stag_id = tag_id + str(count)
	   
		NBNValue = worksheet [sNBN_Id].value
		poleValue = worksheet [sPole_ownership].value
		jointValue = worksheet [sJoint_Use].value
		latitudeValue = worksheet [sLatitude].value
		longitudeValue = worksheet [sLongitude].value
		tagIdValue = worksheet [stag_id].value
		
		if fileName.__eq__(configdict['TPNIFileName']) :   
				
			stls_id = tls_id + str(count)
			tlsIdValue = worksheet [stls_id].value
						   
		elif fileName.__eq__(configdict['UtilFileName']) :
				
			sUtility_Id = Utility_Id + str(count)
			UtilityValue = worksheet [sUtility_Id].value   
	
			sutility_id = utility_id + str(count) 
			utilityIdValue = worksheet [sutility_id].value
		
		if longitudeValue == None:
			break      
		
		dictKey = str(latitudeValue).strip() 
		dictValue = str(longitudeValue).strip()
		coordinates = str(latitudeValue).strip() + "," + str(longitudeValue).strip()

		
		imageName = getStreet(Add=coordinates, SaveLoc=SaveImageLocation)
		
			
		
		if(dictKey != "None"):
			if fileName.__eq__(configdict['TPNIFileName']) :
				xlsDict.update({dictKey + "," + dictValue : str(tlsIdValue) + "|" + str(NBNValue) + "|" + str(poleValue) + "|" + str(jointValue) + "|" + str(tagIdValue) + "|" + str(imageName) + "|" + str(Source)})
			elif fileName.__eq__(configdict['UtilFileName']) :
				xlsDict.update({dictKey + "," + dictValue : str(UtilityValue) + "|" + str(NBNValue) + "|" + str(poleValue) + "|" + str(jointValue) + "|" + str(tagIdValue) + "|" + str(utilityIdValue) + "|" + str(imageName) + "|" + str(Source)})
		count += 1

	return xlsDict

# READ NSSPOLES CSV FILE
def readNSSPoles(folderName, fileName,samName):
	
	print("Started NNS Poles downloading")
	
	Nsscount = 1
	sdict = {}
	
	# IMAGE SAVE LOCATION
	SaveImageLocation = configdict['NNSImageLocation'] + samName + "\\"
	
	if not os.path.exists(SaveImageLocation):
		os.makedirs(SaveImageLocation)
	#print("readNSSPoles")
	
	directory_list = list()
	#print("readNSSPoles")
	for root, dirs, files in os.walk(folderName, topdown=False):
		for name in dirs:
			directory_list.append(os.path.join(root, name))
	#print("readNSSPoles")
	for dir in directory_list:
		if (dir.upper()).__contains__("Telstra_poles".upper()):
			Fname = dir
	Fname = dir        
	FinalFoldername = Fname + "\\" + fileName
  
	with open(FinalFoldername, 'r',encoding="utf-8") as csvfile:

		spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')

		for line in spamreader: 
			
			if(Nsscount != 1):
				
				pdbIdValue = line[3]
				poleOwnerValue = line[12]
				latitudeValue = line[0]

				longitudeValue = line[1]
				poleNumber = line[4]
				poleUse = line[18]
				
				coordinates = latitudeValue + "," + longitudeValue
				
				
				#imageName = coordinates + ".jpg"
				imageName = getStreet(Add=coordinates, SaveLoc=SaveImageLocation)				
					
				sdict.update({str(latitudeValue).strip() + "," + str(longitudeValue).strip()  : pdbIdValue + "|" + imageName + "|" + poleOwnerValue.strip() + "|" + poleNumber + "|" + str(poleUse)})
			Nsscount += 1
	return sdict

	   
	   
		 
	 

	
# READ NSSPOLES CSV FILE
def writeNNSPoles(samName, counter, nssCom, TPNIDict, utilDict):
	
	print("writeNNSPoles...")
	
	Savefilepath = getOuputFileName(samName)
	 
	wb = load_workbook(Savefilepath, data_only=True)
	ws = wb.get_sheet_by_name("Sheet")
	   
	for fKey, fValue in nssCom.items(): 
	
		pdbIdValue = fValue.split("|")[0]
		imageName = fValue.split("|")[1]
		poleOwnerValue = fValue.split("|")[2]
		poleNumber = fValue.split("|")[3]
		poleUse= fValue.split("|")[4]
		
		latitudeValue = fKey.split(",")[0]
		longitudeValue = fKey.split(",")[1]
		
		ws["E" + str(counter)] = latitudeValue.strip()
		ws["F" + str(counter)] = longitudeValue.strip()
		ws["G" + str(counter)] = "nnspole_poles"
		ws["H" + str(counter)] = imageName
		ws["M" + str(counter)] = pdbIdValue
		ws["D" + str(counter)] = str(poleOwnerValue).strip()
		ws["P" + str(counter)] = poleNumber
		ws["U" + str(counter)] = str(poleOwnerValue).strip()
		ws["V" + str(counter)] = latitudeValue
		ws["W" + str(counter)] = longitudeValue
		ws["X" + str(counter)] = poleUse
		
		
	  
		checkRadius(str(latitudeValue).strip(), str(longitudeValue).strip(), ws, counter, TPNIDict, utilDict, "NNS")
		counter += 1
		
		
	wb.save(Savefilepath)
	return counter

#CHECKING RADIUS FOR LNGs AND LATs AND WRITING TO <sam_name>.xlsx file.

def checkRadius(latVal, lngVal, workSheet, counter, fDict, sDict, poleType):
 
	outputColumn1 = "N"
	outputColumn2 = "O"
	outputColumn3 = "P"
	outputColumn4 = "U"
	outputColumn5 = "V"
	outputColumn6 = "W"
	outputColumn7 = "X"
	
	duplicateColumn = "I"
	latLngColumn = "Q"
	poleOwnColumn = "U"
	nbnCoId = "A"
	poleName = "B"
	outputList = ""
	fCount = 0
	sCount = 0
	fCheckList = []
	sCheckList = []
	
		  
	if (poleType == "NNS"):
		pole1 = "TPNI"
		pole2 = "UTILITY"     
	elif (poleType == "TPNI"):
		pole1 = "UTILITY"
		pole2 = "NNS"
	elif (poleType == "UTILITY"):
		pole1 = "TPNI"
		pole2 = "NNS"
	
	if(latVal != 'None'):
			
		for fLatandlng in fDict.keys():
			
			fLat = fLatandlng.split(",")[0]
			fLng = fLatandlng.split(",")[1]
						
			if fLat != "None":
					
				result = dc.distance(float(latVal), float(lngVal), float(fLat), float(fLng))

				if (result < radlength):
				 
					fCheckList.append(fLatandlng)
					fCount += 1               
					outputList += str(latVal + "," + lngVal + "," + fLat + "," + fLng + "|")
					
		
		for sLatandlng in sDict.keys():
			
			sLat = sLatandlng.split(",")[0]
			sLng = sLatandlng.split(",")[1]
			
			if sLat != "None":
					
				result = dc.distance(float(latVal), float(lngVal), float(sLat), float(sLng))

				if (result < radlength):
					
					sCheckList.append(sLatandlng)
					sCount += 1                   
					outputList += str(latVal + "," + lngVal + "," + sLat + "," + sLng + "|")
					
	
	if(fCount >= 1):
		for i in fCheckList:
		  
			StrVal = fDict[i]
			val = StrVal.split("|")[0]
			workSheet[outputColumn1 + str(counter)] = pole1 + "|" + val
			
			if (poleType == "NNS"):
				nbnCoPole = StrVal.split("|")[1]
				workSheet[nbnCoId + str(counter)] = nbnCoPole
				
			del fDict[i]
		workSheet[duplicateColumn + str(counter)] = "Y"
	else:
		workSheet[duplicateColumn + str(counter)] = "N"
		
		 
	if(sCount >= 1):
		
		for i in sCheckList:

			
			
			lat1= i.split(",")[0]
			
			lng1= i.split(",")[1]
			
			StrVal = sDict[i]
			val = StrVal.split("|")[0]
			val1 = StrVal.split("|")[3]
			val2 =  StrVal.split("|")[2]
			val3 =  StrVal.split("|")[4]
			
			workSheet[outputColumn2 + str(counter)] = pole2 + "|" + val
			workSheet[outputColumn3 + str(counter)] = val1
			workSheet[outputColumn4 + str(counter)] = val2
			workSheet[outputColumn5 + str(counter)] = lat1
			workSheet[outputColumn6 + str(counter)] = lng1
			workSheet[outputColumn7 + str(counter)] = val3
			
		 
			if (poleType == "NNS"):
				workSheet[latLngColumn + str(counter)] = i
				nbnCoPole = StrVal.split("|")[1]
				workSheet[nbnCoId + str(counter)] = nbnCoPole
				workSheet[poleName + str(counter)] = val
				poleOwner = StrVal.split("|")[2]
				workSheet[poleOwnColumn + str(counter)] = poleOwner
		
			del sDict[i]
		
		workSheet[duplicateColumn + str(counter)] = "Y"
		
	else:
		workSheet[duplicateColumn + str(counter)] = "N"

	
def checkWitnList(orgDict):
	
	iterList = orgDict
	global remList
	count = 0
	remList={}
	
	for latAndLong in orgDict.keys():
		latVal = latAndLong.split(",")[0]
		lngVal = latAndLong.split(",")[1]
		count = 0
		
		if latVal != "None":
			
			for itlatLong in iterList.keys():
				itLatVal = itlatLong.split(",")[0]
				itLngVal = itlatLong.split(",")[1]
				
				result=dc.distance(float(latVal),float(lngVal),float(itLatVal),float(itLngVal))
				
				if (result < radlength):
					count += 1
					if(count > 1):  
						remList.update({latAndLong:orgDict[latAndLong]})
					
					
	for rem in remList.keys():
		del orgDict[rem]
		
	return remList

def writeDuplicateRecords(dupDict,recordType,counter,samName):
	
	Savefilepath = getOuputFileName(samName)
 
	wb = load_workbook(Savefilepath, data_only=True)
	ws = wb.get_sheet_by_name("Sheet")
	
	
	if (recordType == "TPNI"):
		
		for fKey,fValue in dupDict.items():
			ws["A" + str(counter)] = "Duplicate"
			ws["B" + str(counter)] = fKey.split(",")[0]
			ws["C" + str(counter)] = fKey.split(",")[1]
			ws["E" + str(counter)] = fValue.split("|")[1]
			ws["F" + str(counter)  ] = fValue.split("|")[2]
			ws["G" + str(counter)] = fValue.split("|")[3]

			if(fValue.split("|")[4] != ""):
				ws["H" + str(counter)] = fValue.split("|")[4]
			  
			ws["I" + str(counter)] = fValue.split("|")[0]
			ws["J" + str(counter)] = fValue.split("|")[5]
			ws["K" + str(counter)] = fValue.split("|")[6]
			counter += 1
			
	elif (recordType == "NNS"):
		
		for key,value in dupDict.items():
			ws["A" + str(counter)] = "Duplicate"
			ws["B" + str(counter)] = key.split(",")[0]
			ws["C" + str(counter)] = key.split(",")[1]
			ws["D" + str(counter)] = "nnspole_poles"
			ws["E" + str(counter)] = value.split("|")[1]
			ws["F" + str(counter)] = value.split("|")[0]
			ws["G" + str(counter)] = value.split("|")[2]
			counter += 1
		
	wb.save(Savefilepath)   
	return counter


#CHECK ADDITIONAL ID IN UTILTIY WITH POLE NUMBER IN NNS
def  checkPoles(utilDict,nssCom,TPNIDict,samName,counter):
	
	
	Savefilepath = getOuputFileName(samName)
	templist=[]
	
	if counter == 1:
		# TO CREATE OUTPUT FILE IN PATH
		wb = openpyxl.Workbook()
		wb.save(Savefilepath)
 
	wb = load_workbook(Savefilepath, data_only=True)
	ws = wb.get_sheet_by_name("Sheet")
	
	
	if counter == 1:
		
		ws["A1"] = "NBN_ID"
		ws["B1"] = "Utility_ID"
		ws["C1"] = "Joint_Use"
		ws["D1"] = "Pole_ownership"
		ws["E1"] = "Latitude"
		ws["F1"] = "Longitude"
		ws["G1"] = "Source"
		ws["H1"] = "ImageName"
		ws["I1"] = "Duplicate"
		ws["J1"] = "tag_id"
		ws["K1"] = "utility_id"
		ws["L1"] = "tls_id"
		ws["M1"] = "pdb_id" 
		ws["N1"] = "TPNI_Duplicate"
		ws["P1"] = "Pole_number"
		ws["O1"] = "NNS_Duplicate"
		ws["S1"] = "comment"
		ws["T1"] = "target_asset_flag"
		ws["U1"] = "NNS_Owner"
		ws["V1"] = "NNS_LAT"
		ws["W1"] = "NNS_LONG"
		ws["X1"] = "NNS_POLEUSE"
		counter += 1

	
	for ukey,upole in utilDict.items(): 
		
		if(upole.split("|")[4] != ""):
		
			if(upole.split("|")[4].__len__() >= 4):
					
				for nkey,npole in nssCom.items():

					#owner1=upole.split("|")[2]
					owner2 = npole.split("|")[2]
					if (upole.split("|")[4][-4:] in npole.split("|")[3] and owner2 != "Telstra"):
					 
						for tkey,tpole in TPNIDict.items():
								
							result=dc.distance(float(ukey.split(",")[0]),float(ukey.split(",")[1]),float(tkey.split(",")[0]),float(tkey.split(",")[1]))
							
							if (result < radlength):
								counter = writecheckPoles(ws,counter,ukey,upole,npole,tpole)
								templist.append(ukey)
								templist.append(nkey)
								templist.append(tkey)
							   
								
			else:
				
				for npole in nssCom.values():
						
					#owner1=upole.split("|")[2]
					owner2 = npole.split("|")[2]
				   
					
					if (upole.split("|")[4].__eq__(npole.split("|")[3]) and owner2 != "Telstra"):
						
						for tkey,tpole in TPNIDict.items():
								
							result=dc.distance(float(ukey.split(",")[0]),float(ukey.split(",")[1]),float(tkey.split(",")[0]),float(tkey.split(",")[1]))
							
							if (result < radlength):
							 
									counter = writecheckPoles(ws,counter,ukey,upole,npole,tpole)
									templist.append(ukey)
									templist.append(tkey)

	wb.save(Savefilepath)
	
	for latAndlang in templist:
		
		if latAndlang in  utilDict:
			del utilDict[latAndlang]
		elif latAndlang in  TPNIDict:
			del TPNIDict[latAndlang]
		elif latAndlang in  nssCom:
			del nssCom[latAndlang]    

	return counter

def writecheckPoles(ws,counter,ukey,upole,npole,tpole):
	
  
	ws["A" + str(counter)] = upole.split("|")[1]
	ws["B" + str(counter)] = upole.split("|")[5]
	poleUse= npole.split("|")[4]
	
	if (poleUse in "Shared Use" or poleUse in "Joint Use"):
		
		ws["C" + str(counter)] = "Y"
		ws["S" + str(counter)] = "Desktop Inspected"
		ws["T" + str(counter)] = "N"
		
	#elif (poleUse in "Telstra" or poleUse in "Telstra Only"):
	
		#ws["C" + str(counter)] = "N"
		#ws["S" + str(counter)] = "Desktop Inspected"
		#ws["T" + str(counter)] = "Y"
		
		
	ws["D" + str(counter)] = upole.split("|")[2]
	ws["E" + str(counter)] = ukey.split(",")[0]
	ws["F" + str(counter)] = ukey.split(",")[1]
	ws["G" + str(counter)] = "Additional"
	ws["H" + str(counter)] = upole.split("|")[6]
	ws["I" + str(counter)] = "Y"
	ws["J" + str(counter)] = upole.split("|")[4]
	ws["K" + str(counter)] = upole.split("|")[5]
	ws["L" + str(counter)] = tpole.split("|")[0]
	ws["M" + str(counter)] = npole.split("|")[0]
	
	
	counter += 1
	return counter
		
def readConfigFile(configFilePath):

	file = open(configFilePath, 'r')
	content = file.read()
	paths = content.split("\n") #split it into lines
	for path in paths:
		if(path.__contains__("=")):
			configdict.update({ path.split("=")[0] :  path.split("=")[1]})
	
		
##########################################
# MAIN 
########################################    
def mainFunc():

	global radlength
	global configdict

	configdict = {}
	
	
	configFilePath = "config\\config.properties"
	readConfigFile(configFilePath)
	
	print ("#################################Begin Downloading images #####################################")
	
	
	# TO GET ALL NAMES FROMsam list
	Name_From_List = pickNames()
	
	
	print(Name_From_List)
	
	
	radlength = 6
  
	for samName in Name_From_List:

		print ("#####Downloading images for SAM "+ samName +" #####")

		counter = 1
		fullPath_Name = configdict['SAMInFolderPath'] + samName
		print (fullPath_Name)
		utilDict = {}
		TPNIDict = {}
		nssCom = {}
		NNSDupList={}
		TPNIDupList={}
		poleIdList=[]
		NNSdict={}

		# LOCATION NEEDS TO BE CHANGED.
		folderName = fullPath_Name
		
		# READ files
		TPNIDict = readXls(folderName, configdict['TPNIFileName'] ,samName)
		utilDict = readXls(folderName, configdict['UtilFileName'] ,samName)
		nssCom = readNSSPoles(folderName, configdict['NNSFileName'] ,samName)
	
		TPNIDupList.update(checkWitnList(TPNIDict))
		NNSDupList.update(checkWitnList(nssCom))
		
			
		counter = checkPoles(utilDict,nssCom,TPNIDict,samName,counter)
	
		# WRITE output
		counter = processFile(samName, counter, "utility", nssCom, TPNIDict, utilDict)
		counter = processFile(samName, counter, "TPNI", nssCom, utilDict, TPNIDict)
		counter = writeNNSPoles(samName, counter, nssCom, TPNIDict, utilDict)
	
		counter = writeDuplicateRecords(TPNIDupList,"TPNI",counter,samName)
		writeDuplicateRecords(NNSDupList,"NNS",counter,samName)
		
		
	print ('#################################Download Completed #####################################')
	

if __name__ == '__main__':
#def runMain():
	mainFunc()
