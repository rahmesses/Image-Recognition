import csv
import os

from geopy.geocoders import Nominatim
from pygeocoder import Geocoder
from openpyxl import Workbook
from openpyxl import load_workbook
import openpyxl
 


def pickNames(samListpath):

    Name_From_List = []

    nameRow = 1

    NameBook = openpyxl.load_workbook(samListpath)

    WorkSheet = NameBook.active


    while(WorkSheet['A' + str(nameRow)].value != None):

        Name_From_List.append(str(WorkSheet['A' + str(nameRow)].value))

        nameRow += 1

    return Name_From_List

def writeHeaders(outputPath, outputFileName):

    count = 1
    
    # TO CREATE OUTPUT FOLDER
    if not os.path.exists(outputPath):
        os.makedirs(outputPath)


    # OUTPUT FIELDS TO WRITE

    nbn_id = "A"

    tag_id = "B"

    tls_id = "C"

    pdb_id = "D"

    utility_id = "E"

    joint_use = "F"

    pole_ownership = "G"

    address = "H"

    locality_name = "I"

    latitude = "J"

    longitude = "K"

    nbn_attachmentLabel = "L"

    end_point_id = "M"

    pole_length = "N"

    pole_type = "O"

    pole_material = "P"

    pole_strengthRated = "Q"

    nbn_connectionType = "R"

    riser_ownership = "S"

    riser_size = "T"

    pole_suitable = "U"

    comment = "V"

    target_asset_flag = "W"

    activity_code = "X"

    licence_status = "Y"

    licence_id = "Z"

    licence_start = "AA"

    licence_end = "AB"


    wb = openpyxl.Workbook()

    wb.save(outputPath + "\\" + outputFileName)
  

    wb = load_workbook(outputPath + "\\" + outputFileName, data_only=True)

    worksheet = wb.get_sheet_by_name("Sheet")

   

    worksheet[nbn_id + str(count)] = "nbn_id"

    worksheet[tag_id + str(count)] = "tag_id"

    worksheet[tls_id + str(count)] = "tls_id"

    worksheet[pdb_id + str(count)] = "pdb_id"

    worksheet[utility_id + str(count)] = "utility_id"

    worksheet[joint_use + str(count)] = "joint_use"

    worksheet[pole_ownership + str(count)] = "pole_ownership"

    worksheet[address + str(count)] = "address"

    worksheet[locality_name + str(count)] = "locality_name"

    worksheet[latitude + str(count)] = "latitude"

    worksheet[longitude + str(count)] = "longitude"

    worksheet[nbn_attachmentLabel + str(count)] = "nbn_attachmentLabel"

    worksheet[end_point_id + str(count)] = "end_point_id"

    worksheet[pole_length + str(count)] = "pole_length"

    worksheet[pole_type + str(count)] = "pole_type"

    worksheet[pole_material + str(count)] = "pole_material"

    worksheet[pole_strengthRated + str(count)] = "pole_strengthRated"

    worksheet[nbn_connectionType + str(count)] = "nbn_connectionType"

    worksheet[riser_ownership + str(count)] = "riser_ownership"

    worksheet[riser_size + str(count)] = "riser_size"

    worksheet[pole_suitable + str(count)] = "pole_suitable"

    worksheet[comment + str(count)] = "comment"

    worksheet[target_asset_flag + str(count)] = "target_asset_flag"

    worksheet[activity_code + str(count)] = "activity_code"

    worksheet[licence_status + str(count)] = "licence_status"

    worksheet[licence_id + str(count)] = "licence_id"

    worksheet[licence_start + str(count)] = "licence_start"

    worksheet[licence_end + str(count)] = "licence_end"

        

    wb.save(outputPath + "\\" + outputFileName)

    

def readUtility(inputPath, outputPath, samName, predictDict):

    counter = 2
    count = 2
    
    # INPUT FILE
    
    inputBook = load_workbook(inputPath + "\\" + samName + ".xlsx", data_only=True)

    first_sheet = inputBook.get_sheet_names()[0]

    inputsheet = inputBook.get_sheet_by_name(first_sheet)

    # OUTPUT FILE
    outputBook = load_workbook(outputPath, data_only=True)

    outputSheet = outputBook.get_sheet_by_name("Sheet")


    for row in inputsheet.iter_rows():

        # GET FROM INPUT SHEET
        source = inputsheet ["G" + str(counter)].value
        
        if(source == "Additional"):
            outputSheet["A" + str(count)] = inputsheet ["A" + str(counter)].value
            outputSheet["B" + str(count)] = inputsheet ["J" + str(counter)].value
            outputSheet["C" + str(count)] = inputsheet ["L" + str(counter)].value
            outputSheet["D" + str(count)] = inputsheet ["M" + str(counter)].value
            outputSheet["E" + str(count)] = inputsheet ["B" + str(counter)].value
            outputSheet["F" + str(count)] = inputsheet ["C" + str(counter)].value
            outputSheet["G" + str(count)] = inputsheet ["D" + str(counter)].value
            outputSheet["J" + str(count)] = inputsheet ["E" + str(counter)].value
            outputSheet["K" + str(count)] = inputsheet ["F" + str(counter)].value
            outputSheet["V" + str(count)] = inputsheet ["S" + str(counter)].value
            outputSheet["W" + str(count)] = inputsheet ["T" + str(counter)].value
            count += 1
            counter += 1
            continue
            
            
        
        imageName = inputsheet ["H" + str(counter)].value
        dupcheck1 = inputsheet ["N" + str(counter)].value
        dupcheck2 = inputsheet ["O" + str(counter)].value
        dupcheck3 = inputsheet ["D" + str(counter)].value
        dupcheck4 = inputsheet ["U" + str(counter)].value
        dupcheck5 = outputSheet["V" + str(count)]
        
        if(dupcheck1 != None or dupcheck2 != None):
        
            outputSheet["W" + str(count)] = "N"
            outputSheet["F" + str(count)] = "N"
            

            if(str(imageName) in predictDict):           
                poleType = predictDict.get(str(imageName))
            
                if(("croppedimage" in str(poleType)) or ("cropped" in str(poleType)) or ("nopole" in str(poleType)) or ("No Pole" in str(poleType)) or ("noneimage" in str(poleType))):
                    outputSheet["F" + str(count)] = ""
                    outputSheet["W" + str(count)] = ""
                    outputSheet["V" + str(count)] = "Manual Inspection Required"
                    # counter += 1
                    # continue
                    

                elif(("jointuse" in str(poleType)) and (dupcheck3 != "TELSTRA" )):
                    outputSheet["F" + str(count)] = "Y"
                    outputSheet["W" + str(count)] = "N"
                    outputSheet["V" + str(count)] = "Desktop Inspected"
                elif(("jointuse" in str(poleType)) and (dupcheck3 == "TELSTRA" )):
                    outputSheet["F" + str(count)] = "Y"
                    outputSheet["W" + str(count)] = "N"
                    outputSheet["V" + str(count)] = "Desktop Inspected"
                elif("telstra only" in str(poleType) and dupcheck3 == "TELSTRA" ):
                    outputSheet["F" + str(count)] = "N"
                    outputSheet["W" + str(count)] = "Y"
                    outputSheet["V" + str(count)] = "Desktop Inspected"
                elif(("telstra only" in str(poleType)) and (dupcheck3 != "TELSTRA" )):
                    outputSheet["F" + str(count)] = "Y"
                    outputSheet["W" + str(count)] = "N"
                    outputSheet["V" + str(count)] = "Desktop Inspected"        
           
                elif(("utility only" in str(poleType)) or ("utility bulb" in str(poleType)) or ("utilitybulb" in str(poleType))):
                    outputSheet["V" + str(count)] = "Manual Inspection Required"
                    outputSheet["W" + str(count)] = ""
                
                elif("utility straightpole" in str(poleType) or "utilitystraightpole" in str(poleType) or "maybeutility" in str(poleType) or "utility complex" in str(poleType)):
                    outputSheet["F" + str(count)] = ""
                    outputSheet["W" + str(count)] = ""
                    outputSheet["V" + str(count)] = "Manual Inspection Required"

                elif("noimage" in str(poleType)):
                    outputSheet["F" + str(count)] = ""
                    outputSheet["W" + str(count)] = ""
                    outputSheet["G" + str(count)] = ""
                    outputSheet["V" + str(count)] = "Field Inspection Required - Not Reachable Through Google Maps"
            
            outputSheet["A" + str(count)] = inputsheet ["A" + str(counter)].value
        
            outputSheet["B" + str(count)] = inputsheet ["J" + str(counter)].value
            
            if(dupcheck1 != None):
                fVal = str(dupcheck1).strip().split("|")[0]
                fCheck = str(dupcheck1).strip().split("|")[1]
                if(fVal == "TPNI"):
                    outputSheet["C" + str(count)] = fCheck
            else:
                outputSheet["C" + str(count)] = "000000000000000000"

            if(dupcheck2 != None):
                sVal = str(dupcheck2).strip().split("|")[0]
                sCheck = str(dupcheck2).strip().split("|")[1]
                if(sVal == "NNS"):
                    outputSheet["D" + str(count)] = sCheck
            else:
                outputSheet["D" + str(count)] = "000000"
                
            outputSheet["G" + str(count)] = inputsheet ["D" + str(counter)].value            
            outputSheet["J" + str(count)] = inputsheet ["E" + str(counter)].value
            outputSheet["K" + str(count)] = inputsheet ["F" + str(counter)].value
        
          
            if(inputsheet ["K" + str(counter)].value != None):
                outputSheet["E" + str(count)] = inputsheet ["K" + str(counter)].value
            else:
                outputSheet["E" + str(count)] = "0000000000"
                
                outputSheet["G" + str(count)] = dupcheck4
                outputSheet["J" + str(count)] = inputsheet ["V" + str(counter)].value
                
                outputSheet["K" + str(count)] = inputsheet ["W" + str(counter)].value
                

            if((inputsheet ["L" + str(counter)].value != None) and (dupcheck2 != None)):
                    outputSheet["C" + str(count)] = inputsheet ["L" + str(counter)].value

                    if((inputsheet ["X" + str(counter)].value =="Telstra Only" or inputsheet ["X" + str(counter)].value =="Telstra")and (outputSheet["V" + str(count)].value != "Field Inspection Required - Not Reachable Through Google Maps")) :
                        outputSheet["F" + str(count)] = "N"
                        outputSheet["W" + str(count)] = "Y"
                        outputSheet["V" + str(count)] = "Desktop Inspected"
                        
                        

            if((inputsheet ["J" + str(counter)].value == None) and (dupcheck2 != None)):
                    outputSheet["B" + str(count)] = inputsheet ["P" + str(counter)].value
                    
            else:
                outputSheet["B" + str(count)] = inputsheet ["J" + str(counter)].value
            
            
            if(str(source).__eq__("nnspole_poles")):
            
                outputSheet["B" + str(count)] = inputsheet ["P" + str(counter)].value            
                outputSheet["D" + str(count)] = inputsheet ["M" + str(counter)].value
                outputSheet["A" + str(count)] = inputsheet ["A" + str(counter)].value
                
                if(inputsheet ["Q" + str(counter)].value != None):
                    langAndLot = str(inputsheet ["Q" + str(counter)].value)
                    lang = langAndLot.split(",")[0]
                    longt = langAndLot.split(",")[1]
                    outputSheet["J" + str(count)] = lang
                    outputSheet["K" + str(count)] = longt
                
                
                if(inputsheet ["B" + str(counter)].value != None):
                    outputSheet["E" + str(count)] = inputsheet ["B" + str(counter)].value
                else:
                    outputSheet["E" + str(count)] = "0000000000"
                    
                    outputSheet["G" + str(count)] = dupcheck4
                    outputSheet["J" + str(count)] = inputsheet ["V" + str(counter)].value
                    outputSheet["K" + str(count)] = inputsheet ["W" + str(counter)].value

	            

            count += 1
        counter += 1
            
    outputBook.save(outputPath)

def ATSFormatting(outputPath, samName):

    count = 2
    
    print("Removing Comment Misses")

    # OUTPUT FILE
    outputBook = load_workbook(outputPath, data_only=True)

    outputSheet = outputBook.get_sheet_by_name("Sheet")


    for row in outputSheet.iter_rows():

        if(outputSheet["V" + str(count)].value == None and outputSheet["D" + str(count)].value != None and outputSheet["C" + str(count)].value != None):
               
	        outputSheet["F" + str(count)] = None
	        outputSheet["W" + str(count)] = None
	        outputSheet["V" + str(count)] = "Manual Inspection Required"
                
			
        if(outputSheet["G" + str(count)].value == "OTHER" or outputSheet["G" + str(count)].value == "OTHERS" or outputSheet["G" + str(count)].value == "UNKNOWN"):
                outputSheet["V" + str(count)] = "Manual Inspection Required"
                outputSheet["F" + str(count)] = None
                outputSheet["W" + str(count)] = None

        if(outputSheet["V" + str(count)].value == "Field Inspection Required - Not Reachable Through Google Maps"):
            
            outputSheet["G" + str(count)].value = ""
            outputSheet["W" + str(count)].value = "N"

        if((outputSheet["E" + str(count)].value == "0000000000" or outputSheet["C" + str(count)].value == "000000000000000000" or outputSheet["D" + str(count)].value == "000000") and (outputSheet["V" + str(count)].value == "Desktop Inspected")):

            outputSheet["V" + str(count)] = "Manual Inspection Required"
            outputSheet["F" + str(count)] = None
            outputSheet["W" + str(count)] = None

        count += 1
       
        
    outputBook.save(outputPath)

#def addAddress(outputPath, samName):

    #counter = 2
    #checkList = []

    #outputBook = load_workbook(outputPath, data_only=True)

    #outputSheet = outputBook.get_sheet_by_name("Sheet")

    #for row in outputSheet.iter_rows():

        #cord1 = outputSheet["J" + str(counter)].value
        #cord2 = outputSheet["k" + str(counter)].value
    

       # if(cord1 != None and cord2 != None):

            #checkList.append(cord1)
            #checkList.append(cord2)
            

            #geolocator = Nominatim()
            #location = geolocator.reverse(lat,)
         
        #counter += 1

    #outputBook.save(outputPath)

def writeToNssFile():
    
    print("writeToNssFile")
    

def readPredictData(samName):
    
    lineCount = 1
    datadict = {}
    # OUTPUT FILE
    FinalFoldername = "C:\\Users\\shanmugam.thandapani\\tf_files\\OutPut_" + samName + ".csv"
    
    with open(FinalFoldername, 'r') as csvfile:

        spamreader = csv.reader(csvfile, delimiter='|')

        for line in spamreader:

            if(lineCount != 1):

                valList = line[0].split('/')[-1]
                Ivalue = line[1].strip()
                
                datadict.update({valList : Ivalue})
            
            lineCount += 1
    
    return datadict


def LoadTLSFile(TLSFilePath):
    print("readJointUse...")
    
    count = 1
    TLSList = []
     
    TLSBook = load_workbook(TLSFilePath, data_only=True)
    firstSheet = TLSBook.get_sheet_names()[0]
    TLSsheet = TLSBook.get_sheet_by_name(firstSheet)
    
    for row in TLSsheet.iter_rows():
    
        TPNIVal = TLSsheet ["C" + str(count)].value
        NNSVal = TLSsheet ["D" + str(count)].value
        UtilVal = TLSsheet ["E" + str(count)].value
        
        TLSList.append(str(TPNIVal) + "," + str(NNSVal) + "," + str(UtilVal))
        count += 1
    
    return TLSList
        
    
def getFiliteredNNSList(samInputPath, TLSList, num, dupCheck, sheetColumn, fileName):
    
    orgList = [] 
    fliteredList = []
    tempList = []
   
    FinalFoldername = samInputPath + "\\" + fileName
    
    for temVal in TLSList:
        tempList.append(temVal.split(",")[num])
        
    with open(FinalFoldername, 'r') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for line in spamreader:
            orgList.append(line[3])
    
    for lines in orgList:
        if lines not in tempList:
            fliteredList.append(lines)
           
    return fliteredList

def getDupFiliteredNNSList(samInputPath, TLSList, num, dupCheck, sheetColumn, fileName):
    
    orgList = [] 
    fliteredList = []
    tempList = []
   
    FinalFoldername = samInputPath + "\\" + fileName
    
    for temVal in TLSList:
        tempList.append(temVal.split(",")[num])
        
    with open(FinalFoldername, 'r') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for line in spamreader:
            orgList.append(line[3])
    
    for lines in orgList:
        if lines in tempList:
            fliteredList.append(lines)
           
    return fliteredList
    
def writeNNSData(nssInputPath, inFile, outputPath, outFile, fliteredNNSId):
    print("writeNNSData")
    
    finalInputPath = nssInputPath + "\\" + inFile
    finalOutputPath = outputPath + "\\" + outFile
    
    with open(finalInputPath, 'r') as csvfile:

        spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')

        for line in spamreader: 
    
            if line[3] not in fliteredNNSId:
                
                with open(finalOutputPath, 'a') as csvfile:
                    spamwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
                    spamwriter.writerow(line)
                   
            
def getFiliteredList(samOutputPath, samName, TLSList, num, dupCheck, sheetColumn, fileName):
    
    count = 2
    orgList = [] 
    fliteredList = []
    tempList = []
    
    samPath = samOutputPath + samName + "\\"
      
    xlsBook = load_workbook(samPath + fileName , data_only=True)
    firstSheet = xlsBook.get_sheet_names()[0]
    xlssheet = xlsBook.get_sheet_by_name(firstSheet)
    
    for row in xlssheet.iter_rows():
        orgList.append(str(xlssheet[sheetColumn + str(count)].value))
        count += 1

    for temVal in TLSList:
        tempList.append(temVal.split(",")[num])

    for lines in orgList:
        if lines not in tempList:
            fliteredList.append(lines)
    
    return fliteredList

def getUtilFiliteredList(samOutputPath, samName, TLSList, predictDict, num, dupCheck, sheetColumn, fileName):
    
    count = 2
    orgDict = {}
    fliteredList = []
    tempList = []
    
    samPath = samOutputPath + samName + "\\"
      
    xlsBook = load_workbook(samPath + fileName , data_only=True)
    firstSheet = xlsBook.get_sheet_names()[0]
    xlssheet = xlsBook.get_sheet_by_name(firstSheet)
    
    for row in xlssheet.iter_rows():
        orgDict.update({str(xlssheet[sheetColumn + str(count)].value) :  (str(xlssheet["K" + str(count)].value) + "," + str(xlssheet["L" + str(count)].value) + ".jpg").strip() })
        count += 1

    for temVal in TLSList:
        tempList.append(temVal.split(",")[num])

    for lines in orgDict.keys():
        if lines not in tempList:
            orgImgName = orgDict[lines]
            if orgImgName in predictDict.keys():
                poletype = predictDict[orgImgName]
                if(poletype != "utility only"):
                    fliteredList.append(lines)
    
    return fliteredList


def getDupFiliteredList(samOutputPath, samName, TLSList, num, dupCheck, sheetColumn, fileName):
    
    count = 2
    orgList = [] 
    fliteredList = []
    tempList = []
    
    samPath = samOutputPath + samName + "\\"
      
    xlsBook = load_workbook(samPath + fileName , data_only=True)
    firstSheet = xlsBook.get_sheet_names()[0]
    xlssheet = xlsBook.get_sheet_by_name(firstSheet)
    
    for row in xlssheet.iter_rows():
        orgList.append(str(xlssheet[sheetColumn + str(count)].value))
        count += 1

    for temVal in TLSList:
        tempList.append(temVal.split(",")[num])

    for lines in orgList:
        if lines in tempList:
            fliteredList.append(lines)

    return fliteredList


def getDupUtilFiliteredList(samOutputPath, samName, TLSList, predictDict, num, dupCheck, sheetColumn, fileName):
    
    count = 2
    orgDict = {}
    fliteredList = []
    tempList = []
    
    samPath = samOutputPath + samName + "\\"
      
    xlsBook = load_workbook(samPath + fileName , data_only=True)
    firstSheet = xlsBook.get_sheet_names()[0]
    xlssheet = xlsBook.get_sheet_by_name(firstSheet)
    
    for row in xlssheet.iter_rows():
        orgDict.update({str(xlssheet[sheetColumn + str(count)].value) :  (str(xlssheet["K" + str(count)].value) + "," + str(xlssheet["L" + str(count)].value) + ".jpg").strip() })
        count += 1

    for temVal in TLSList:
        tempList.append(temVal.split(",")[num])

    for lines in orgDict.keys():
        if lines in tempList:
            fliteredList.append(lines)
        else:
            orgImgName = orgDict[lines]
            if orgImgName in predictDict.keys():
                poletype = predictDict[orgImgName]
                if(poletype == "utility only"):
                    fliteredList.append(lines)
    
    return fliteredList

def writeValues(TPNIOutputSheet, TPNIInputsheet, outputCounter, inputCounter):
    
    TPNIOutputSheet["A" + str(str(outputCounter))] = TPNIInputsheet["A" + str(inputCounter)].value
    TPNIOutputSheet["B" + str(outputCounter)] = TPNIInputsheet["B" + str(inputCounter)].value
    TPNIOutputSheet["C" + str(outputCounter)] = TPNIInputsheet["C" + str(inputCounter)].value
    TPNIOutputSheet["D" + str(outputCounter)] = TPNIInputsheet["D" + str(inputCounter)].value
    TPNIOutputSheet["E" + str(outputCounter)] = TPNIInputsheet["E" + str(inputCounter)].value
    TPNIOutputSheet["F" + str(outputCounter)] = TPNIInputsheet["F" + str(inputCounter)].value
    TPNIOutputSheet["G" + str(outputCounter)] = TPNIInputsheet["G" + str(inputCounter)].value
    TPNIOutputSheet["H" + str(outputCounter)] = TPNIInputsheet["H" + str(inputCounter)].value
    TPNIOutputSheet["I" + str(outputCounter)] = TPNIInputsheet["I" + str(inputCounter)].value
    TPNIOutputSheet["J" + str(outputCounter)] = TPNIInputsheet["J" + str(inputCounter)].value
    TPNIOutputSheet["K" + str(outputCounter)] = TPNIInputsheet["K" + str(inputCounter)].value
    TPNIOutputSheet["L" + str(outputCounter)] = TPNIInputsheet["L" + str(inputCounter)].value
    TPNIOutputSheet["M" + str(outputCounter)] = TPNIInputsheet["M" + str(inputCounter)].value
    TPNIOutputSheet["N" + str(outputCounter)] = TPNIInputsheet["N" + str(inputCounter)].value
    TPNIOutputSheet["O" + str(outputCounter)] = TPNIInputsheet["O" + str(inputCounter)].value
    TPNIOutputSheet["P" + str(outputCounter)] = TPNIInputsheet["P" + str(inputCounter)].value
    TPNIOutputSheet["Q" + str(outputCounter)] = TPNIInputsheet["Q" + str(inputCounter)].value
    TPNIOutputSheet["R" + str(outputCounter)] = TPNIInputsheet["R" + str(inputCounter)].value
    TPNIOutputSheet["S" + str(outputCounter)] = TPNIInputsheet["S" + str(inputCounter)].value
    TPNIOutputSheet["T" + str(outputCounter)] = TPNIInputsheet["T" + str(inputCounter)].value
    TPNIOutputSheet["U" + str(outputCounter)] = TPNIInputsheet["U" + str(inputCounter)].value
    TPNIOutputSheet["V" + str(outputCounter)] = TPNIInputsheet["V" + str(inputCounter)].value
    TPNIOutputSheet["W" + str(outputCounter)] = TPNIInputsheet["W" + str(inputCounter)].value
    TPNIOutputSheet["X" + str(outputCounter)] = TPNIInputsheet["X" + str(inputCounter)].value
    TPNIOutputSheet["Y" + str(outputCounter)] = TPNIInputsheet["Y" + str(inputCounter)].value
    TPNIOutputSheet["Z" + str(outputCounter)] = TPNIInputsheet["Z" + str(inputCounter)].value
    TPNIOutputSheet["AA" + str(outputCounter)] = TPNIInputsheet["AA" + str(inputCounter)].value
    TPNIOutputSheet["AB" + str(outputCounter)] = TPNIInputsheet["AB" + str(inputCounter)].value
    TPNIOutputSheet["AC" + str(outputCounter)] = TPNIInputsheet["AC" + str(inputCounter)].value
    TPNIOutputSheet["AD" + str(outputCounter)] = TPNIInputsheet["AD" + str(inputCounter)].value
    TPNIOutputSheet["AE" + str(outputCounter)] = TPNIInputsheet["AE" + str(inputCounter)].value
    TPNIOutputSheet["AF" + str(outputCounter)] = TPNIInputsheet["AF" + str(inputCounter)].value
    TPNIOutputSheet["AG" + str(outputCounter)] = TPNIInputsheet["AG" + str(inputCounter)].value
    TPNIOutputSheet["AH" + str(outputCounter)] = TPNIInputsheet["AH" + str(inputCounter)].value
    
    
def writeTUData(samFilePath, outputPath, fliteredTPNIId, InFileName, outFileName, position):
    print("writeTUData")
    
    
    inputFile = samFilePath + "\\" + InFileName
    outputFile = outputPath + "\\" + outFileName
    
    inputCounter = 1
    outputCounter = 1
        
    # INPUT PATH
    inputBook = load_workbook(inputFile, data_only=True)
    firstSheet = inputBook.get_sheet_names()[0]
    inputSheet = inputBook.get_sheet_by_name(firstSheet)
    
    # SAVING THE OUTPUT FILE
    wb = openpyxl.Workbook()
    wb.save(outputFile)
    
    # OUTPUT FILE
    outputBook = load_workbook(outputFile, data_only=True)
    outputSheet = outputBook.get_sheet_by_name("Sheet")
    
    if(InFileName == "TPNI_data.xlsx"):
    
        for TPNI in fliteredTPNIId:
            
            inputCounter = 1
            for row in inputSheet.iter_rows():
                
                if (TPNI == ((inputSheet[position + str(inputCounter)].value).strip())):
                    
                    writeValues(outputSheet, inputSheet, outputCounter, inputCounter)
                    outputCounter += 1
                    break
                    
                inputCounter += 1
        
    elif(InFileName == "Utility_data.xlsx"):

        for util in fliteredTPNIId:
            
            inputCounter = 1
            for row in inputSheet.iter_rows():
                
                imageName = str(inputSheet["K" + str(inputCounter)].value) + "," + str(inputSheet["L" + str(inputCounter)].value) + ".jpg"
              
                if (util == (str(inputSheet[position + str(inputCounter)].value).strip())):
                
                    writeValues(outputSheet, inputSheet, outputCounter, inputCounter)
                    outputCounter += 1
                    break
                    
                inputCounter += 1
        
    outputBook.save(outputFile)
    

def writeDupValues(TPNIOutputSheet, TPNIInputsheet, outputCounter, inputCounter):
    
    if(outputCounter == 1):
        TPNIOutputSheet["A" + str(str(outputCounter))] = "NBN_ID"
        TPNIOutputSheet["B" + str(outputCounter)] = "Utility_ID"
        TPNIOutputSheet["C" + str(outputCounter)] = "Pole_ID"
        TPNIOutputSheet["D" + str(outputCounter)] = "Pole Owner"
        TPNIOutputSheet["E" + str(outputCounter)] = "Latitude"
        TPNIOutputSheet["F" + str(outputCounter)] = "Longitude"
        TPNIOutputSheet["G" + str(outputCounter)] = "Source"
    else:
        TPNIOutputSheet["A" + str(str(outputCounter))] = TPNIInputsheet["G" + str(inputCounter)].value
        TPNIOutputSheet["B" + str(outputCounter)] = TPNIInputsheet["D" + str(inputCounter)].value
        TPNIOutputSheet["C" + str(outputCounter)] = TPNIInputsheet["G" + str(inputCounter)].value
        TPNIOutputSheet["D" + str(outputCounter)] = TPNIInputsheet["H" + str(inputCounter)].value
        TPNIOutputSheet["E" + str(outputCounter)] = TPNIInputsheet["K" + str(inputCounter)].value
        TPNIOutputSheet["F" + str(outputCounter)] = TPNIInputsheet["L" + str(inputCounter)].value
        TPNIOutputSheet["G" + str(outputCounter)] = "Utility"

    
def writeUtiloly(samFilePath, outputPath, dupfliteredData, InFileName, outFileName, position):
     
    inputFile = samFilePath + "\\" + InFileName
    outputFile = outputPath + "\\" + outFileName
    
    inputCounter = 1
    outputCounter = 1
        
    # INPUT PATH
    inputBook = load_workbook(inputFile, data_only=True)
    firstSheet = inputBook.get_sheet_names()[0]
    inputSheet = inputBook.get_sheet_by_name(firstSheet)
    
    # SAVING THE OUTPUT FILE
    wb = openpyxl.Workbook()
    wb.save(outputFile)
    
    # OUTPUT FILE
    outputBook = load_workbook(outputFile, data_only=True)
    outputSheet = outputBook.get_sheet_by_name("Sheet")
    
    for val in dupfliteredData:
        
        inputCounter = 1
        for row in inputSheet.iter_rows():
    
            if (val == ((inputSheet[position + str(inputCounter)].value).strip())):
                
                writeDupValues(outputSheet, inputSheet, outputCounter, inputCounter)
                outputCounter += 1
                break
                
            inputCounter += 1
                
    outputBook.save(outputFile)
     
def removeDuplicates(samFolderPath, samName, outputPath, TLSList, predictDict):
    
    print("removeDuplicates...")
    TPNIInFileName = "TPNI_data.xlsx"
    TPNIDupFileName = "TPNI_dup_data.xlsx"
    
    utilInFileName = "Utility_data.xlsx"
    utilDupFileName = "UtilityOnlyPoles_" + samName + ".xlsx"
    
    nnsInFileName = "nnspole_poles.csv"
    nnsDupFileName = "dup_nnspole_poles.csv"
    
    TPNIEmptCheck = "000000000000000000"
    utilEmptCheck = "0000000000"
    nnsEmptCheck = "000000"
    
    TPNIField = "B"
    utilField = "D"
    nnsField = "D"
    
    TPNIPosition = 0
    utilPosition = 2
    nnsPosition = 1
    
    
    directory_list = list()
    for root, dirs, files in os.walk(samFolderPath + "\\" + samName, topdown=False):
        for name in dirs:
            directory_list.append(os.path.join(root, name))

    for dir in directory_list:
        if (dir.upper()).__contains__("Telstra_poles".upper()):
            nssInputPath = dir
    nssInputPath = dir
    samFilePath = samFolderPath + "\\" + samName
    
    fliteredTPNIId = getFiliteredList(samFolderPath, samName, TLSList, TPNIPosition, TPNIEmptCheck, TPNIField, TPNIInFileName)
    fliteredUtilId = getUtilFiliteredList(samFolderPath, samName, TLSList, predictDict, utilPosition, utilEmptCheck, utilField, utilInFileName)
    fliteredNNSId = getFiliteredNNSList(nssInputPath, TLSList, nnsPosition, nnsEmptCheck, nnsField, nnsInFileName)
    
    fliteredDupTPNIId = getDupFiliteredList(samFolderPath, samName, TLSList, TPNIPosition, TPNIEmptCheck, TPNIField, TPNIInFileName)
    fliteredDupUtilId = getDupUtilFiliteredList(samFolderPath, samName, TLSList, predictDict, utilPosition, utilEmptCheck, utilField, utilInFileName)
    fliteredDupNNSId = getDupFiliteredNNSList(nssInputPath, TLSList, nnsPosition, nnsEmptCheck, nnsField, nnsInFileName)
    
    writeTUData(samFilePath, outputPath, fliteredTPNIId, TPNIInFileName, TPNIInFileName, TPNIField)
    writeTUData(samFilePath, outputPath, fliteredUtilId, utilInFileName, utilInFileName, utilField)
    writeNNSData(nssInputPath, nnsInFileName, outputPath, nnsInFileName, fliteredNNSId)
    
    writeTUData(samFilePath, outputPath, fliteredDupTPNIId, TPNIInFileName, TPNIDupFileName, TPNIField)
    writeUtiloly(samFilePath, outputPath, fliteredDupUtilId, utilInFileName, utilDupFileName, utilField)
    writeNNSData(nssInputPath, nnsInFileName, outputPath, nnsDupFileName, fliteredDupNNSId)
    
def readConfigFile(configFilePath):

    file = open(configFilePath, 'r')
    content = file.read()
    paths = content.split("\n") #split it into lines
    for path in paths:
        if(path.__contains__("=")):
            configdict.update({ path.split("=")[0] :  path.split("=")[1]})
    
    
def mainPart():

    global configdict

    configdict = {}
    configFilePath = "config\\config.properties"
    readConfigFile(configFilePath)
    
    
    samFolderPath = configdict['SAMFolderPath']
    constantFolderPath = configdict['TLSFolderPath']
    samListpath = configdict['samList']
    
    Name_From_List = pickNames(samListpath)

    for samName in Name_From_List:
        
        print ("#####Generating TLS for SAM "+ samName +" #####")
        
        predictDict = readPredictData(samName)
        
        filePath = constantFolderPath + samName

        outputFileName = "TLS_" + samName + ".xlsx"
        
        finalOutputPath = filePath + "\\" + outputFileName
        
        writeHeaders(filePath, outputFileName)
        
        readUtility(filePath, finalOutputPath, samName, predictDict)
        
        TLSList = LoadTLSFile(finalOutputPath)
        
        removeDuplicates(samFolderPath, samName, filePath, TLSList, predictDict)

        ATSFormatting(finalOutputPath, samName)

        #addAddress(finalOutputPath, samName)
		
 # def callMain():
if __name__ == '__main__':
    mainPart()
