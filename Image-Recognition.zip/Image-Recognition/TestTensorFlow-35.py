﻿from _sqlite3 import Row
import csv
import os
import sys

import tensorflow as tf

def pickNames(foldername):
    
    samList = []
    
    with open(foldername, 'r') as csvfile:
    
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')

        for line in spamreader: 
        
            samValue = line[0]
            samList.append(str(samValue).strip())
            
    return samList
        
def savePredictionHistory(imageName, poleType, score,samName):
    
    row = [imageName, poleType, score]    
    
    outPutFile = 'C:/Users/shanmugam.thandapani/tf_files/OutPut_' + samName + '.csv';
    
    if os.path.exists(outPutFile) : 
        with open(outPutFile, 'a',newline='') as csvfile:
            spamwriter = csv.writer(csvfile, delimiter='|', quoting=csv.QUOTE_MINIMAL)
            spamwriter.writerow(row)
    else:
        with open(outPutFile, 'w',newline='') as csvfile:
            spamwriter = csv.writer(csvfile, delimiter='|', quoting=csv.QUOTE_MINIMAL)
            spamwriter.writerow(['Image Name', 'Pole Type', 'Score'])
            spamwriter.writerow(row)

def telstraPoleValidation(samName):
    label_lines = [line.rstrip() for line in tf.gfile.GFile("C:/Users/shanmugam.thandapani/tf_files/Tensor_Telstra/retrained_labels.txt")]
    with tf.gfile.FastGFile("C:/Users/shanmugam.thandapani/tf_files/Tensor_Telstra/retrained_graph.pb", 'r') as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())
        _ = tf.import_graph_def(graph_def, name='')
    
    inputDir = 'C:/Users/shanmugam.thandapani/tf_files/Tensor_Telstra/Pole_Test/' + samName
    
    for streetView in os.listdir (inputDir) :
            StreetViewImagePath= os.path.realpath(os.path.join(inputDir,streetView))
            # change this as you see fit
            image_path = StreetViewImagePath
        
            # Read in the image_data
            print("Image Name: " +image_path +"::::::::Count: ")
            image_data = tf.gfile.FastGFile(image_path, 'r').read()
            
            with tf.Session() as sess:
                
                try :
                    # Feed the image_data as input to the graph and get first prediction
                    softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
                
                    predictions = sess.run(softmax_tensor, \
                         {'DecodeJpeg/contents:0': image_data})
                
                    # Sort to show labels of first prediction in order of confidence
                    top_k = predictions[0].argsort()[-len(predictions[0]):][::-1]           
    
                    i=0    
                    counter = 0
                    for node_id in top_k:
                         
                            if (i==0):
                                i=1
                                human_string = label_lines[node_id]
                                score = predictions[0][node_id]
                                if(score<0.40):
                                    human_string='No Pole'
                                    counter = counter + 1
                                print('%s (score = %.5f)' % (human_string, score))            
                                savePredictionHistory(image_path, human_string, score,samName)
                except Exception:
                    print(Exception)
            
def utilityPoleValidation(samName):
    label_lines = [line.rstrip() for line 
                    in tf.gfile.GFile("C:/Users/shanmugam.thandapani/tf_files/Tensor_Utility/retrained_labels.txt")]

    # Unpersists graph from file
    with tf.gfile.FastGFile("C:/Users/shanmugam.thandapani/tf_files/Tensor_Utility/retrained_graph.pb", 'r') as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())
        _ = tf.import_graph_def(graph_def, name='')

    inputDir = 'C:/Users/shanmugam.thandapani/tf_files/Tensor_Utility/Pole_Test/' + samName
    
    for streetView in os.listdir (inputDir) :
            StreetViewImagePath= os.path.realpath(os.path.join(inputDir,streetView))
            # change this as you see fit
            image_path = StreetViewImagePath
        
            # Read in the image_data
            print("Image Name: " +image_path +"::::::::Count: ")
            image_data = tf.gfile.FastGFile(image_path, 'r').read()
            
            
            
            with tf.Session() as sess:
                
                try : 
                    # Feed the image_data as input to the graph and get first prediction
                    softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
                
                    predictions = sess.run(softmax_tensor, \
                         {'DecodeJpeg/contents:0': image_data})
                
                    #Sort to show labels of first prediction in order of confidence
                    top_k = predictions[0].argsort()[-len(predictions[0]):][::-1]           
    
                    i=0    
                    counter = 0
                    for node_id in top_k:
                     
                            if (i==0):
                                i=1
                                human_string = label_lines[node_id]
                                score = predictions[0][node_id]
                                if(score<0.40):
                                    human_string='No Pole'
                                    counter = counter + 1
                                print('%s (score = %.5f)' % (human_string, score))            
                                savePredictionHistory(image_path, human_string, score,samName)
                            
                except Exception:
                    print(Exception)

##############################################################################################
######################################### MAIN ###############################################
##############################################################################################

# import images and then process records
if __name__ == '__main__':

    samList  = pickNames('C:/Users/shanmugam.thandapani/tf_files/Sam.csv')
    print(samList)
    
    
    for samName in samList:
        
        utilityPoleValidation(samName)
        telstraPoleValidation(samName)
