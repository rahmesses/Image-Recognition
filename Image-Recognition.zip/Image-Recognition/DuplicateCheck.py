import urllib, os

from openpyxl import Workbook
from openpyxl import load_workbook
import math


def distance(lat1, lng1, lat2, lng2):
    
    radius = 6371 * 1000
    
    dLat = (lat2-lat1) * math.pi / 180
    dLng = (lng2-lng1) * math.pi / 180
    
    lat1 = lat1 * math.pi / 180
    lat2 = lat2 * math.pi / 180
    
    val = math.sin(dLat/2) * math.sin(dLat/2) + math.sin(dLng/2) * math.sin(dLng/2) * math.cos(lat1) * math.cos(lat2)    
    ang = 2 * math.atan2(math.sqrt(val), math.sqrt(1-val))
    return radius * ang


#if __name__ == '__main__':
