from _sqlite3 import Row
import csv

from openpyxl import Workbook
from openpyxl import load_workbook
import openpyxl

import FrameTLS as TLS


def pickNames(samListpath):

    Name_From_List=[]

    nameRow = 1

    NameBook = openpyxl.load_workbook(samListpath)

    WorkSheet = NameBook.active


    while(WorkSheet['A' + str(nameRow)].value != None):

        Name_From_List.append(str(WorkSheet['A' + str(nameRow)].value))

        nameRow +=1

    return Name_From_List


def predictandUpdateData(samName):

    FolderName = '/tf_files/'+samName
    FileName = samName+'.xlsx'
    
    SaveLocation = FolderName +"/" + FileName
    
    resultFileName = '/tf_files/OutPut.csv'

    workbook = load_workbook(SaveLocation, data_only=True)

    first_sheet = workbook.get_sheet_names()[0]    

    worksheet = workbook.get_sheet_by_name(first_sheet)

    count = 1
    for row in worksheet.iter_rows(): 

        if (count != 1):
            
            imageField = "H" + str (count) 
    
            imageName = worksheet [imageField].value
    
            with open(resultFileName, 'r') as csvfile:
    
                spamreader = csv.reader(csvfile, delimiter='|', quotechar='"')
    
                for row2 in spamreader: 
    
                    if row2[0].find(str(imageName[1:])) == -1:     
    
                        continue
    
                    else:
    
                        value1 = str(row2[0])
    
                        value2 = str(imageName[1:])
    
                        print ('Value: ' +value2)
    
                        worksheet ["O"  + str (count)] = str(value1)
    
                        worksheet ["P"  + str (count)] = row2[1]
    
                        worksheet ["Q"  + str (count)] = row2[2] 
    
                        break                                  

        count = count+1

        workbook.save(SaveLocation)

    

#if __name__ == '__main__':
def predictMain():

    samListpath = "/tf_files/SAMList.xlsx"    
    Name_From_List = pickNames(samListpath)
    
    for samName in Name_From_List:
        predictandUpdateData(samName)
        
    #TLS.callMain()
